echo -e '\033]2;Allium (GRLC) - zpool pool\007'
./CryptoDredge -a allium -o stratum+tcp://allium.eu.mine.zpool.ca:6433 -u 3DKh3qR7xASVxqigArQYA9juGxVxTnYcdz -p c=BTC
printf "Press <ENTER> to continue..."
read -r continueKey
