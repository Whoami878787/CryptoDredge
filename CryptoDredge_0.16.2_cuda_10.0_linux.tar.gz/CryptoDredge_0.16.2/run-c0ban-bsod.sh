echo -e '\033]2;Lyra2REvc0ban (c0ban) - bsod pool\007'
./CryptoDredge -a lyra2vc0ban -o stratum+tcp://eu.bsod.pw:2514 -u benchmark -p x
printf "Press <ENTER> to continue..."
read -r continueKey
