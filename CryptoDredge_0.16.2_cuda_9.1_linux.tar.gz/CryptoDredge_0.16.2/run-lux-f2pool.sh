echo -e '\033]2;Phi2 (LUX) - f2pool pool\007'
./CryptoDredge -a phi2 -o stratum+tcp://lux.f2pool.com:5780 -u LNLnxfvZWP9BZXpwHDDP8UB6bAxFwnJd2x -p x
printf "Press <ENTER> to continue..."
read -r continueKey
