echo -e '\033]2;Lyra2REv3 (VTC) - gos pool\007'
./CryptoDredge -a lyra2v3 -o stratum+tcp://eu.gos.cx:4505 -u benchmark -p x
printf "Press <ENTER> to continue..."
read -r continueKey
